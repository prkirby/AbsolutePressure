# WordPress MySQL database migration
#
# Generated: Wednesday 3. February 2016 04:47 UTC
# Hostname: localhost
# Database: `absolute_pressure`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_cb_contact_form`
#

DROP TABLE IF EXISTS `wp_cb_contact_form`;


#
# Table structure of table `wp_cb_contact_form`
#

CREATE TABLE `wp_cb_contact_form` (
  `form_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_name` varchar(200) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_contact_form`
#
INSERT INTO `wp_cb_contact_form` ( `form_id`, `form_name`) VALUES
(1, 'Contact Form Demo') ;

#
# End of data contents of table `wp_cb_contact_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_create_control_form`
#

DROP TABLE IF EXISTS `wp_cb_create_control_form`;


#
# Table structure of table `wp_cb_create_control_form`
#

CREATE TABLE `wp_cb_create_control_form` (
  `control_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(50) NOT NULL,
  `form_id` int(10) NOT NULL,
  `column_dynamicId` int(10) NOT NULL,
  `sorting_order` int(10) NOT NULL,
  PRIMARY KEY (`control_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_create_control_form`
#
INSERT INTO `wp_cb_create_control_form` ( `control_id`, `field_id`, `form_id`, `column_dynamicId`, `sorting_order`) VALUES
(1, 1, 1, 1, 1),
(2, 3, 1, 2, 2),
(3, 1, 1, 3, 3),
(4, 2, 1, 4, 4) ;

#
# End of data contents of table `wp_cb_create_control_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_dynamic_settings`
#

DROP TABLE IF EXISTS `wp_cb_dynamic_settings`;


#
# Table structure of table `wp_cb_dynamic_settings`
#

CREATE TABLE `wp_cb_dynamic_settings` (
  `dynamic_settings_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dynamicId` int(10) NOT NULL,
  `dynamic_settings_key` varchar(100) NOT NULL,
  `dynamic_settings_value` text NOT NULL,
  PRIMARY KEY (`dynamic_settings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_dynamic_settings`
#
INSERT INTO `wp_cb_dynamic_settings` ( `dynamic_settings_id`, `dynamicId`, `dynamic_settings_key`, `dynamic_settings_value`) VALUES
(1, 1, 'cb_label_value', 'Your Name'),
(2, 1, 'cb_description', ''),
(3, 1, 'cb_control_required', '1'),
(4, 1, 'cb_tooltip_txt', ''),
(5, 1, 'cb_default_txt_val', 'Your Name'),
(6, 1, 'cb_admin_label', 'Your Name'),
(7, 1, 'cb_show_email', '0'),
(8, 1, 'cb_checkbox_alpha_filter', '0'),
(9, 1, 'cb_ux_checkbox_alpha_num_filter', '0'),
(10, 1, 'cb_checkbox_digit_filter', '0'),
(11, 1, 'cb_checkbox_strip_tag_filter', '0'),
(12, 1, 'cb_checkbox_trim_filter', '0'),
(13, 2, 'cb_label_value', 'Your Email'),
(14, 2, 'cb_description', ''),
(15, 2, 'cb_control_required', '1'),
(16, 2, 'cb_tooltip_txt', ''),
(17, 2, 'cb_default_txt_val', 'Your Email'),
(18, 2, 'cb_admin_label', 'Your Email'),
(19, 2, 'cb_show_email', '0'),
(20, 3, 'cb_label_value', 'Subject'),
(21, 3, 'cb_description', ''),
(22, 3, 'cb_control_required', '0'),
(23, 3, 'cb_tooltip_txt', ''),
(24, 3, 'cb_default_txt_val', 'Subject'),
(25, 3, 'cb_admin_label', 'Subject'),
(26, 3, 'cb_show_email', '0'),
(27, 3, 'cb_checkbox_alpha_filter', '0'),
(28, 3, 'cb_ux_checkbox_alpha_num_filter', '0'),
(29, 3, 'cb_checkbox_digit_filter', '0'),
(30, 3, 'cb_checkbox_strip_tag_filter', '0'),
(31, 3, 'cb_checkbox_trim_filter', '0'),
(32, 4, 'cb_label_value', 'Your Message'),
(33, 4, 'cb_description', ''),
(34, 4, 'cb_control_required', '0'),
(35, 4, 'cb_tooltip_txt', ''),
(36, 4, 'cb_default_txt_val', 'Your Message'),
(37, 4, 'cb_admin_label', 'Your Message'),
(38, 4, 'cb_show_email', '0'),
(39, 4, 'cb_checkbox_alpha_filter', '0'),
(40, 4, 'cb_ux_checkbox_alpha_num_filter', '0'),
(41, 4, 'cb_checkbox_digit_filter', '0'),
(42, 4, 'cb_checkbox_strip_tag_filter', '0'),
(43, 4, 'cb_checkbox_trim_filter', '0') ;

#
# End of data contents of table `wp_cb_dynamic_settings`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_email_template_admin`
#

DROP TABLE IF EXISTS `wp_cb_email_template_admin`;


#
# Table structure of table `wp_cb_email_template_admin`
#

CREATE TABLE `wp_cb_email_template_admin` (
  `email_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email_to` varchar(100) NOT NULL,
  `email_from` varchar(100) NOT NULL,
  `body_content` text NOT NULL,
  `subject` varchar(400) NOT NULL,
  `send_to` int(1) NOT NULL,
  `form_id` int(10) NOT NULL,
  `from_name` varchar(200) NOT NULL,
  `reply_to` varchar(200) NOT NULL,
  `cc` varchar(200) NOT NULL,
  `bcc` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_email_template_admin`
#
INSERT INTO `wp_cb_email_template_admin` ( `email_id`, `email_to`, `email_from`, `body_content`, `subject`, `send_to`, `form_id`, `from_name`, `reply_to`, `cc`, `bcc`, `name`) VALUES
(1, 'paulrdkirby@gmail.com', 'paulrdkirby@gmail.com', 'Hello Admin,<br><br>\r\n				A new user has visited your website.<br><br>\r\n				Here are the details :<br><br>\r\n				<strong>Your Name</strong>: [control_1] <br><strong>Your Email</strong>: [control_2] <br><strong>Subject</strong>: [control_3] <br><strong>Your Message</strong>: [control_4] <br>\r\n				<br>Thanks,<br><br>\r\n				<strong>Technical Support Team</strong>', 'New Contact recieved from Website', 0, 1, 'Site Administration', '', '', '', 'Admin Notification'),
(2, '', 'paulrdkirby@gmail.com', 'Hi,<br><br>\r\n	Thanks for visiting our website. We will be Contacting you soon next 24 hours.<br><br>\r\n	<br>Thanks,<br><br>\r\n	<strong>Support Team</strong>', 'Thanks for visiting our website', 0, 1, 'Site Administration', '', '', '', 'Client Notification') ;

#
# End of data contents of table `wp_cb_email_template_admin`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_form_settings_table`
#

DROP TABLE IF EXISTS `wp_cb_form_settings_table`;


#
# Table structure of table `wp_cb_form_settings_table`
#

CREATE TABLE `wp_cb_form_settings_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) NOT NULL,
  `form_message_key` varchar(200) NOT NULL,
  `form_message_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_form_settings_table`
#
INSERT INTO `wp_cb_form_settings_table` ( `id`, `form_id`, `form_message_key`, `form_message_value`) VALUES
(1, 1, 'redirect', '0'),
(2, 1, 'redirect_url', ''),
(3, 1, 'success_message', 'Your message was sent successfully. Thanks.'),
(4, 1, 'blank_field_message', 'Required field must not be blank'),
(5, 1, 'incorrect_email_message', 'Please enter a valid email address'),
(6, 1, 'form_description', '') ;

#
# End of data contents of table `wp_cb_form_settings_table`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_frontend_data_table`
#

DROP TABLE IF EXISTS `wp_cb_frontend_data_table`;


#
# Table structure of table `wp_cb_frontend_data_table`
#

CREATE TABLE `wp_cb_frontend_data_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) NOT NULL,
  `field_Id` int(10) NOT NULL,
  `dynamic_control_id` int(10) NOT NULL,
  `dynamic_frontend_value` text NOT NULL,
  `form_submit_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_frontend_data_table`
#

#
# End of data contents of table `wp_cb_frontend_data_table`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_frontend_forms_table`
#

DROP TABLE IF EXISTS `wp_cb_frontend_forms_table`;


#
# Table structure of table `wp_cb_frontend_forms_table`
#

CREATE TABLE `wp_cb_frontend_forms_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) NOT NULL,
  `submit_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_frontend_forms_table`
#

#
# End of data contents of table `wp_cb_frontend_forms_table`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_layout_settings_table`
#

DROP TABLE IF EXISTS `wp_cb_layout_settings_table`;


#
# Table structure of table `wp_cb_layout_settings_table`
#

CREATE TABLE `wp_cb_layout_settings_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` int(10) NOT NULL,
  `form_settings_key` varchar(200) NOT NULL,
  `form_settings_value` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_layout_settings_table`
#
INSERT INTO `wp_cb_layout_settings_table` ( `id`, `form_id`, `form_settings_key`, `form_settings_value`) VALUES
(1, 1, 'label_setting_font_family', 'inherit'),
(2, 1, 'label_setting_font_color', '#000000'),
(3, 1, 'label_setting_font_style', 'normal'),
(4, 1, 'label_setting_font_size', '16'),
(5, 1, 'label_setting_font_align_left', '0'),
(6, 1, 'label_setting_label_position', 'top'),
(7, 1, 'label_setting_field_size', '11'),
(8, 1, 'label_setting_field_align', 'left'),
(9, 1, 'label_setting_hide_label', '0'),
(10, 1, 'label_setting_text_direction', 'inherit'),
(11, 1, 'input_field_font_family', 'inherit'),
(12, 1, 'input_field_font_color', '#000000'),
(13, 1, 'input_field_font_style', 'normal'),
(14, 1, 'input_field_font_size', '14'),
(15, 1, 'input_field_border_radius', '0'),
(16, 1, 'input_field_border_color', '#e5e5e5'),
(17, 1, 'input_field_border_size', '1'),
(18, 1, 'input_field_border_style', 'solid'),
(19, 1, 'input_field_clr_bg_color', '#ffffff'),
(20, 1, 'input_field_rdl_multiple_row', '1'),
(21, 1, 'input_field_rdl_text_align', '0'),
(22, 1, 'input_field_text_direction', 'inherit'),
(23, 1, 'input_field_input_size', 'layout-span10'),
(24, 1, 'submit_button_font_family', 'inherit'),
(25, 1, 'submit_button_text', 'Submit'),
(26, 1, 'submit_button_font_style', 'normal'),
(27, 1, 'submit_button_font_size', '12'),
(28, 1, 'submit_button_button_width', '100'),
(29, 1, 'submit_button_bg_color', '#24890d'),
(30, 1, 'submit_button_hover_bg_color', '#3dd41a'),
(31, 1, 'submit_button_text_color', '#ffffff'),
(32, 1, 'submit_button_border_color', '#000000'),
(33, 1, 'submit_button_border_size', '0'),
(34, 1, 'submit_button_border_radius', '0'),
(35, 1, 'submit_button_rdl_text_align', '0'),
(36, 1, 'submit_button_text_direction', 'inherit'),
(37, 1, 'success_msg_font_family', 'inherit'),
(38, 1, 'success_msg_font_size', '12'),
(39, 1, 'success_msg_bg_color', '#e5ffd5'),
(40, 1, 'success_msg_border_color', '#e5ffd5'),
(41, 1, 'success_msg_text_color', '#6aa500'),
(42, 1, 'success_msg_rdl_text_align', '0'),
(43, 1, 'success_msg_text_direction', 'inherit'),
(44, 1, 'error_msg_font_family', 'inherit'),
(45, 1, 'error_msg_font_size', '12'),
(46, 1, 'error_msg_bg_color', '#ffcaca'),
(47, 1, 'error_msg_border_color', '#ffcaca'),
(48, 1, 'error_msg_text_color', '#ff2c38'),
(49, 1, 'error_msg_rdl_text_align', '0'),
(50, 1, 'error_msg_text_direction', 'inherit') ;

#
# End of data contents of table `wp_cb_layout_settings_table`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_licensing`
#

DROP TABLE IF EXISTS `wp_cb_licensing`;


#
# Table structure of table `wp_cb_licensing`
#

CREATE TABLE `wp_cb_licensing` (
  `licensing_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(10) NOT NULL,
  `type` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `api_key` text NOT NULL,
  `order_id` varchar(100) NOT NULL,
  PRIMARY KEY (`licensing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_licensing`
#
INSERT INTO `wp_cb_licensing` ( `licensing_id`, `version`, `type`, `url`, `api_key`, `order_id`) VALUES
(1, '2.1.0', 'Contact Bank', 'http://localhost', '', '') ;

#
# End of data contents of table `wp_cb_licensing`
# --------------------------------------------------------



#
# Delete any existing table `wp_cb_roles_capability`
#

DROP TABLE IF EXISTS `wp_cb_roles_capability`;


#
# Table structure of table `wp_cb_roles_capability`
#

CREATE TABLE `wp_cb_roles_capability` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `roles_capability_key` varchar(200) NOT NULL,
  `roles_capability_value` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cb_roles_capability`
#
INSERT INTO `wp_cb_roles_capability` ( `id`, `roles_capability_key`, `roles_capability_value`) VALUES
(1, 'admin_full_control', '1'),
(2, 'admin_read_control', '0'),
(3, 'admin_write_control', '0'),
(4, 'editor_full_control', '0'),
(5, 'editor_read_control', '1'),
(6, 'editor_write_control', '0'),
(7, 'author_full_control', '0'),
(8, 'author_read_control', '1'),
(9, 'author_write_control', '0'),
(10, 'contributor_full_control', '0'),
(11, 'contributor_read_control', '1'),
(12, 'contributor_write_control', '0'),
(13, 'subscriber_full_control', '0'),
(14, 'subscriber_read_control', '1'),
(15, 'subscriber_write_control', '0') ;

#
# End of data contents of table `wp_cb_roles_capability`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost', 'yes'),
(2, 'home', 'http://localhost', 'yes'),
(3, 'blogname', 'Absolute Pressure Washing', 'yes'),
(4, 'blogdescription', 'Quality Slogan Here', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'paulrdkirby@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/index.php/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'hack_file', '0', 'yes'),
(30, 'blog_charset', 'UTF-8', 'yes'),
(31, 'moderation_keys', '', 'no'),
(32, 'active_plugins', 'a:5:{i:0;s:29:"contact-bank/contact-bank.php";i:1;s:41:"password-protected/password-protected.php";i:2;s:43:"shortcodes-ultimate/shortcodes-ultimate.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";i:4;s:27:"wp-super-cache/wp-cache.php";}', 'yes'),
(33, 'category_base', '', 'yes'),
(34, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(35, 'comment_max_links', '2', 'yes'),
(36, 'gmt_offset', '0', 'yes'),
(37, 'default_email_category', '1', 'yes'),
(38, 'recently_edited', '', 'no'),
(39, 'template', 'corpobox', 'yes'),
(40, 'stylesheet', 'corpobox', 'yes'),
(41, 'comment_whitelist', '1', 'yes'),
(42, 'blacklist_keys', '', 'no'),
(43, 'comment_registration', '0', 'yes'),
(44, 'html_type', 'text/html', 'yes'),
(45, 'use_trackback', '0', 'yes'),
(46, 'default_role', 'subscriber', 'yes'),
(47, 'db_version', '35700', 'yes'),
(48, 'uploads_use_yearmonth_folders', '1', 'yes'),
(49, 'upload_path', '', 'yes'),
(50, 'blog_public', '0', 'yes'),
(51, 'default_link_category', '2', 'yes'),
(52, 'show_on_front', 'page', 'yes'),
(53, 'tag_base', '', 'yes'),
(54, 'show_avatars', '1', 'yes'),
(55, 'avatar_rating', 'G', 'yes'),
(56, 'upload_url_path', '', 'yes'),
(57, 'thumbnail_size_w', '150', 'yes'),
(58, 'thumbnail_size_h', '150', 'yes'),
(59, 'thumbnail_crop', '1', 'yes'),
(60, 'medium_size_w', '300', 'yes'),
(61, 'medium_size_h', '300', 'yes'),
(62, 'avatar_default', 'mystery', 'yes'),
(63, 'large_size_w', '1024', 'yes'),
(64, 'large_size_h', '1024', 'yes'),
(65, 'image_default_link_type', 'none', 'yes'),
(66, 'image_default_size', '', 'yes'),
(67, 'image_default_align', '', 'yes'),
(68, 'close_comments_for_old_posts', '0', 'yes'),
(69, 'close_comments_days_old', '14', 'yes'),
(70, 'thread_comments', '1', 'yes'),
(71, 'thread_comments_depth', '5', 'yes'),
(72, 'page_comments', '0', 'yes'),
(73, 'comments_per_page', '50', 'yes'),
(74, 'default_comments_page', 'newest', 'yes'),
(75, 'comment_order', 'asc', 'yes'),
(76, 'sticky_posts', 'a:0:{}', 'yes'),
(77, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'uninstall_plugins', 'a:2:{s:27:"wp-super-cache/wp-cache.php";s:22:"wpsupercache_uninstall";s:29:"contact-bank/contact-bank.php";s:40:"plugin_uninstall_script_for_contact_bank";}', 'no'),
(81, 'timezone_string', '', 'yes'),
(82, 'page_for_posts', '0', 'yes'),
(83, 'page_on_front', '77', 'yes'),
(84, 'default_post_format', '0', 'yes'),
(85, 'link_manager_enabled', '0', 'yes'),
(86, 'finished_splitting_shared_terms', '1', 'yes'),
(87, 'site_icon', '0', 'yes'),
(88, 'medium_large_size_w', '768', 'yes'),
(89, 'medium_large_size_h', '0', 'yes'),
(90, 'initial_db_version', '35700', 'yes'),
(91, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(92, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'sidebars_widgets', 'a:11:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:18:"home-one-prebefore";a:0:{}s:15:"home-one-before";a:0:{}s:14:"home-one-after";a:0:{}s:17:"home-page-section";a:1:{i:0;s:24:"corpobox_action_widget-4";}s:7:"footer1";a:0:{}s:7:"footer2";a:0:{}s:7:"footer3";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:6:{i:1454475073;a:1:{s:11:"wp_cache_gc";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1454512140;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1454553157;a:1:{s:24:"contact_bank_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1454555347;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1454556548;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(118, 'can_compress_scripts', '0', 'yes'),
(137, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1452827468;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(138, 'current_theme', 'Corpobox', 'yes'),
(139, 'theme_mods_corpobox', 'a:10:{i:0;b:0;s:23:"corpobox_headerbg_color";s:7:"#00394c";s:20:"corpobox_hover_color";s:7:"#b84ad3";s:16:"header_textcolor";s:5:"blank";s:19:"corpobox_frame_logo";b:1;s:11:"logo_upload";s:53:"http://localhost/wp-content/uploads/2016/01/Logo.jpeg";s:18:"nav_menu_locations";a:2:{s:7:"primary";i:2;s:3:"top";i:2;}s:12:"home_tagline";s:0:"";s:18:"home_tagline_bgimg";s:0:"";s:26:"corpobox_display_pagetitle";b:1;}', 'yes'),
(140, 'theme_switched', '', 'yes'),
(141, 'widget_corpobox_icon_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(142, 'widget_mwp_featured_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(143, 'widget_corpobox_action_widget', 'a:3:{i:2;a:4:{s:9:"text_main";s:50:"This will be the main text for the call to action!";s:11:"button_text";s:17:"Get a FREE quote!";s:10:"button_url";s:0:"";s:10:"background";s:11:"transparent";}s:12:"_multiwidget";i:1;i:4;a:4:{s:9:"text_main";s:43:"Contact us for a free evaluation and quote!";s:11:"button_text";s:9:"Get Quote";s:10:"button_url";s:1:"#";s:10:"background";s:11:"transparent";}}', 'yes'),
(144, 'widget_corpobox_featured_page', 'a:2:{i:2;a:2:{s:5:"title";s:13:"Featured Page";s:7:"page_id";s:2:"77";}s:12:"_multiwidget";i:1;}', 'yes'),
(145, 'widget_corpobox_authorbox', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(150, 'recently_activated', 'a:0:{}', 'yes'),
(155, 'password_protected_version', '2.0.2', 'yes'),
(157, 'password_protected_status', '1', 'yes'),
(158, 'password_protected_feeds', '0', 'yes'),
(159, 'password_protected_administrators', '1', 'yes'),
(160, 'password_protected_users', '0', 'yes'),
(161, 'password_protected_password', '305e4714ee2f2dff84b27a2668468121', 'yes'),
(162, 'password_protected_allowed_ip_addresses', '184.155.130.102', 'yes'),
(168, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(173, 'rewrite_rules', 'a:79:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:57:"index.php/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:52:"index.php/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:45:"index.php/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:27:"index.php/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:54:"index.php/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:49:"index.php/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:42:"index.php/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:24:"index.php/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:55:"index.php/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:50:"index.php/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:43:"index.php/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:25:"index.php/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:42:"index.php/feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:37:"index.php/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:30:"index.php/page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:37:"index.php/comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=77&cpage=$matches[1]";s:51:"index.php/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:46:"index.php/comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:54:"index.php/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:49:"index.php/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:42:"index.php/search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:24:"index.php/search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:57:"index.php/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:52:"index.php/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:45:"index.php/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:27:"index.php/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:79:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:49:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:66:"index.php/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:54:"index.php/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:36:"index.php/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:53:"index.php/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:48:"index.php/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:41:"index.php/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:23:"index.php/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:68:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:78:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:98:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:93:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:74:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:63:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:67:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:87:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:75:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:82:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:71:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:57:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:67:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:87:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:82:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:63:"index.php/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:74:"index.php/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:61:"index.php/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:48:"index.php/([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:37:"index.php/.?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"index.php/.?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"index.php/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"index.php/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:43:"index.php/.?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:26:"index.php/(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:30:"index.php/(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:50:"index.php/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:45:"index.php/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:38:"index.php/(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:45:"index.php/(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:34:"index.php/(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(178, 'su_installed', '1452829409', 'yes'),
(179, 'su_option_version', '4.9.9', 'yes'),
(180, 'widget_shortcodes-ultimate', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(181, 'su_option_custom-formatting', 'on', 'yes'),
(182, 'su_option_skip', 'on', 'yes'),
(183, 'su_option_prefix', 'su_', 'yes'),
(184, 'su_option_hotkey', 'alt+i', 'yes'),
(185, 'su_option_skin', 'default', 'yes'),
(186, 'su_option_custom-css', '', 'yes'),
(187, 'sunrise_defaults_su', '1', 'yes'),
(232, 'su_vote', 'no', 'yes'),
(237, 'ossdl_off_cdn_url', 'http://localhost', 'yes'),
(238, 'ossdl_off_include_dirs', 'wp-content,wp-includes', 'yes'),
(239, 'ossdl_off_exclude', '.php', 'yes'),
(240, 'ossdl_cname', '', 'yes'),
(241, 'wp_super_cache_index_detected', '3', 'yes'),
(242, 'wpsupercache_start', '1454293843', 'yes'),
(243, 'wpsupercache_count', '0', 'yes'),
(248, 'contact-bank-updation-check-url', 'http://tech-banker.com/wp-admin/admin-ajax.php', 'yes'),
(249, 'contact-bank-version-number', '2.1', 'yes'),
(250, 'contact-bank-automatic_update', '1', 'yes'),
(251, 'widget_contact_bank_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(253, 'wpsupercache_gc_time', '1454474473', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(5, 2, '_edit_lock', '1452828397:1'),
(6, 5, '_wp_attached_file', '2016/01/apw_logo1.jpeg'),
(7, 5, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:498;s:6:"height";i:139;s:4:"file";s:22:"2016/01/apw_logo1.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"apw_logo1-150x139.jpeg";s:5:"width";i:150;s:6:"height";i:139;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"apw_logo1-300x84.jpeg";s:5:"width";i:300;s:6:"height";i:84;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"apw_logo1-400x139.jpeg";s:5:"width";i:400;s:6:"height";i:139;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:22:"apw_logo1-140x139.jpeg";s:5:"width";i:140;s:6:"height";i:139;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(8, 6, '_wp_attached_file', '2016/01/Apt-left-side-after.jpg'),
(9, 6, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:31:"2016/01/Apt-left-side-after.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"Apt-left-side-after-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"Apt-left-side-after-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:32:"Apt-left-side-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"Apt-left-side-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:31:"Apt-left-side-after-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:32:"Apt-left-side-after-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:33:"Apt-left-side-after-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:31:"Apt-left-side-after-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:33:"Apt-left-side-after-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005579;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(10, 7, '_wp_attached_file', '2016/01/Apt-left-side-before.jpg'),
(11, 7, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:32:"2016/01/Apt-left-side-before.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"Apt-left-side-before-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"Apt-left-side-before-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:33:"Apt-left-side-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:33:"Apt-left-side-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:32:"Apt-left-side-before-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:33:"Apt-left-side-before-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:34:"Apt-left-side-before-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:32:"Apt-left-side-before-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:34:"Apt-left-side-before-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005596;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(12, 8, '_wp_attached_file', '2016/01/Apt-right-side-after.jpg'),
(13, 8, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:32:"2016/01/Apt-right-side-after.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"Apt-right-side-after-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"Apt-right-side-after-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:33:"Apt-right-side-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:33:"Apt-right-side-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:32:"Apt-right-side-after-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:33:"Apt-right-side-after-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:34:"Apt-right-side-after-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:32:"Apt-right-side-after-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:34:"Apt-right-side-after-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005585;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(14, 9, '_wp_attached_file', '2016/01/Apt-right-side-before.jpg'),
(15, 9, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:33:"2016/01/Apt-right-side-before.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"Apt-right-side-before-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"Apt-right-side-before-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:34:"Apt-right-side-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:34:"Apt-right-side-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:33:"Apt-right-side-before-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:34:"Apt-right-side-before-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:35:"Apt-right-side-before-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:33:"Apt-right-side-before-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:35:"Apt-right-side-before-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005594;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(16, 10, '_wp_attached_file', '2016/01/Bobcat-after.jpeg'),
(17, 10, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:25:"2016/01/Bobcat-after.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Bobcat-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Bobcat-after-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"Bobcat-after-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"Bobcat-after-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Bobcat-after-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:26:"Bobcat-after-800x1632.jpeg";s:5:"width";i:800;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:27:"Bobcat-after-1080x1632.jpeg";s:5:"width";i:1080;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:25:"Bobcat-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:27:"Bobcat-after-1200x1632.jpeg";s:5:"width";i:1200;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1337540409;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"64";s:13:"shutter_speed";s:17:"0.022222222222222";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(18, 11, '_wp_attached_file', '2016/01/Bobcat-before.jpeg'),
(19, 11, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:26:"2016/01/Bobcat-before.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Bobcat-before-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Bobcat-before-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"Bobcat-before-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"Bobcat-before-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"Bobcat-before-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:27:"Bobcat-before-800x1632.jpeg";s:5:"width";i:800;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:28:"Bobcat-before-1080x1632.jpeg";s:5:"width";i:1080;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:26:"Bobcat-before-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:28:"Bobcat-before-1200x1632.jpeg";s:5:"width";i:1200;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1337540235;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"64";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(20, 12, '_wp_attached_file', '2016/01/Brick-after.jpg'),
(21, 12, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:23:"2016/01/Brick-after.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"Brick-after-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"Brick-after-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"Brick-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"Brick-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"Brick-after-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:24:"Brick-after-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:25:"Brick-after-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:23:"Brick-after-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:25:"Brick-after-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005431;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(22, 13, '_wp_attached_file', '2016/01/Brick-before.jpg'),
(23, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:24:"2016/01/Brick-before.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Brick-before-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"Brick-before-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"Brick-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Brick-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"Brick-before-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:25:"Brick-before-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:26:"Brick-before-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:24:"Brick-before-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:26:"Brick-before-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005436;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(24, 14, '_wp_attached_file', '2016/01/Brick-patio.jpg'),
(25, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:23:"2016/01/Brick-patio.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"Brick-patio-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"Brick-patio-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"Brick-patio-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"Brick-patio-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"Brick-patio-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:24:"Brick-patio-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:25:"Brick-patio-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:23:"Brick-patio-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:25:"Brick-patio-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005595;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(26, 15, '_wp_attached_file', '2016/01/Cedar-house-after.jpeg'),
(27, 15, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:30:"2016/01/Cedar-house-after.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Cedar-house-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"Cedar-house-after-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:30:"Cedar-house-after-400x300.jpeg";s:5:"width";i:400;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:30:"Cedar-house-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(28, 16, '_wp_attached_file', '2016/01/Cedar-house-before.jpeg'),
(29, 16, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:31:"2016/01/Cedar-house-before.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"Cedar-house-before-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"Cedar-house-before-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:31:"Cedar-house-before-400x300.jpeg";s:5:"width";i:400;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:31:"Cedar-house-before-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(30, 17, '_wp_attached_file', '2016/01/Cedar-house-side-by-side.jpeg'),
(31, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:37:"2016/01/Cedar-house-side-by-side.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:37:"Cedar-house-side-by-side-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:37:"Cedar-house-side-by-side-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:37:"Cedar-house-side-by-side-400x300.jpeg";s:5:"width";i:400;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:37:"Cedar-house-side-by-side-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(32, 18, '_wp_attached_file', '2016/01/Cement.jpeg'),
(33, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1632;s:6:"height";i:1224;s:4:"file";s:19:"2016/01/Cement.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"Cement-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"Cement-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"Cement-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"Cement-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:19:"Cement-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:20:"Cement-800x1224.jpeg";s:5:"width";i:800;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:21:"Cement-1080x1224.jpeg";s:5:"width";i:1080;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:19:"Cement-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:21:"Cement-1200x1224.jpeg";s:5:"width";i:1200;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1337074724;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"80";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:6;s:8:"keywords";a:0:{}}}'),
(34, 19, '_wp_attached_file', '2016/01/Cement-beforeafter.jpg'),
(35, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:30:"2016/01/Cement-beforeafter.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Cement-beforeafter-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"Cement-beforeafter-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"Cement-beforeafter-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:31:"Cement-beforeafter-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:30:"Cement-beforeafter-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:31:"Cement-beforeafter-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:32:"Cement-beforeafter-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:30:"Cement-beforeafter-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:32:"Cement-beforeafter-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005418;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(36, 20, '_wp_attached_file', '2016/01/Cement-steps.jpg'),
(37, 20, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:24:"2016/01/Cement-steps.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Cement-steps-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"Cement-steps-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"Cement-steps-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Cement-steps-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"Cement-steps-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:25:"Cement-steps-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:26:"Cement-steps-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:24:"Cement-steps-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:26:"Cement-steps-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005423;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(38, 21, '_wp_attached_file', '2016/01/Deck.jpg'),
(39, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:16:"2016/01/Deck.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"Deck-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"Deck-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:16:"Deck-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:17:"Deck-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:16:"Deck-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:17:"Deck-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:18:"Deck-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:16:"Deck-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:18:"Deck-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005584;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(40, 22, '_wp_attached_file', '2016/01/Deck-after.jpeg'),
(41, 22, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:23:"2016/01/Deck-after.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"Deck-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"Deck-after-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"Deck-after-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"Deck-after-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"Deck-after-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:24:"Deck-after-800x2048.jpeg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:25:"Deck-after-1080x2048.jpeg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:23:"Deck-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:25:"Deck-after-1200x2048.jpeg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1433935300;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(42, 23, '_wp_attached_file', '2016/01/Deck-after-2.jpeg'),
(43, 23, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:25:"2016/01/Deck-after-2.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Deck-after-2-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Deck-after-2-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"Deck-after-2-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"Deck-after-2-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Deck-after-2-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:26:"Deck-after-2-800x2048.jpeg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:27:"Deck-after-2-1080x2048.jpeg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:25:"Deck-after-2-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:27:"Deck-after-2-1200x2048.jpeg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1433339619;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:3:"125";s:13:"shutter_speed";s:17:"0.033333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(44, 24, '_wp_attached_file', '2016/01/Deck-before.jpeg'),
(45, 24, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:24:"2016/01/Deck-before.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Deck-before-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"Deck-before-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"Deck-before-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Deck-before-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"Deck-before-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:25:"Deck-before-800x1536.jpeg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:26:"Deck-before-1080x1536.jpeg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:24:"Deck-before-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:26:"Deck-before-1200x1536.jpeg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1433337235;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"64";s:13:"shutter_speed";s:17:"0.033333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(46, 25, '_wp_attached_file', '2016/01/Deck-cleaning.jpeg'),
(47, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:26:"2016/01/Deck-cleaning.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Deck-cleaning-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Deck-cleaning-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"Deck-cleaning-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"Deck-cleaning-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"Deck-cleaning-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:27:"Deck-cleaning-800x2048.jpeg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:28:"Deck-cleaning-1080x2048.jpeg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:26:"Deck-cleaning-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:28:"Deck-cleaning-1200x2048.jpeg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1433337209;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:3:"160";s:13:"shutter_speed";s:17:"0.033333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(48, 26, '_wp_attached_file', '2016/01/Denver-truck-fleet.jpeg'),
(49, 26, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:31:"2016/01/Denver-truck-fleet.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"Denver-truck-fleet-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"Denver-truck-fleet-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:32:"Denver-truck-fleet-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"Denver-truck-fleet-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:31:"Denver-truck-fleet-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:32:"Denver-truck-fleet-800x1632.jpeg";s:5:"width";i:800;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:33:"Denver-truck-fleet-1080x1632.jpeg";s:5:"width";i:1080;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:31:"Denver-truck-fleet-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:33:"Denver-truck-fleet-1200x1632.jpeg";s:5:"width";i:1200;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1336323122;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"64";s:13:"shutter_speed";s:18:"0.0014492753623188";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(50, 27, '_wp_attached_file', '2016/01/Dock.jpeg'),
(51, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:17:"2016/01/Dock.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"Dock-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"Dock-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"Dock-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:18:"Dock-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"Dock-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:18:"Dock-800x1632.jpeg";s:5:"width";i:800;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:19:"Dock-1080x1632.jpeg";s:5:"width";i:1080;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:17:"Dock-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:19:"Dock-1200x1632.jpeg";s:5:"width";i:1200;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1336651293;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"64";s:13:"shutter_speed";s:19:"0.00075187969924812";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(52, 28, '_wp_attached_file', '2016/01/Driveway.jpg'),
(53, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:20:"2016/01/Driveway.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"Driveway-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"Driveway-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"Driveway-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"Driveway-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"Driveway-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:21:"Driveway-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:22:"Driveway-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:20:"Driveway-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:22:"Driveway-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005589;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(54, 29, '_wp_attached_file', '2016/01/Driveway-after.jpeg'),
(55, 29, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:27:"2016/01/Driveway-after.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Driveway-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"Driveway-after-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"Driveway-after-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"Driveway-after-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:27:"Driveway-after-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:28:"Driveway-after-800x1632.jpeg";s:5:"width";i:800;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:29:"Driveway-after-1080x1632.jpeg";s:5:"width";i:1080;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:27:"Driveway-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:29:"Driveway-after-1200x1632.jpeg";s:5:"width";i:1200;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1337175586;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"64";s:13:"shutter_speed";s:18:"0.0012239902080783";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(56, 30, '_wp_attached_file', '2016/01/Driveway-before.jpeg'),
(57, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:28:"2016/01/Driveway-before.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Driveway-before-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Driveway-before-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"Driveway-before-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Driveway-before-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Driveway-before-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Driveway-before-800x1632.jpeg";s:5:"width";i:800;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Driveway-before-1080x1632.jpeg";s:5:"width";i:1080;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Driveway-before-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Driveway-before-1200x1632.jpeg";s:5:"width";i:1200;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1337166661;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"64";s:13:"shutter_speed";s:18:"0.0029239766081871";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(58, 31, '_wp_attached_file', '2016/01/Equipment.jpg'),
(59, 31, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:21:"2016/01/Equipment.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"Equipment-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"Equipment-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"Equipment-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"Equipment-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"Equipment-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:22:"Equipment-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:23:"Equipment-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:21:"Equipment-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:23:"Equipment-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005409;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(60, 32, '_wp_attached_file', '2016/01/Garage-after.jpeg'),
(61, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:25:"2016/01/Garage-after.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Garage-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Garage-after-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Garage-after-400x300.jpeg";s:5:"width";i:400;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:25:"Garage-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(62, 33, '_wp_attached_file', '2016/01/Garage-before.jpeg'),
(63, 33, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:26:"2016/01/Garage-before.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Garage-before-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Garage-before-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"Garage-before-400x300.jpeg";s:5:"width";i:400;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:26:"Garage-before-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(64, 34, '_wp_attached_file', '2016/01/Garage-sealing.jpeg'),
(65, 34, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"file";s:27:"2016/01/Garage-sealing.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Garage-sealing-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"Garage-sealing-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"Garage-sealing-768x768.jpeg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Garage-sealing-1024x1024.jpeg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:27:"Garage-sealing-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:28:"Garage-sealing-800x2048.jpeg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:29:"Garage-sealing-1080x2048.jpeg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:27:"Garage-sealing-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:29:"Garage-sealing-1200x2048.jpeg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1432981643;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(66, 35, '_wp_attached_file', '2016/01/Gutter-1.jpg') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(67, 35, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:20:"2016/01/Gutter-1.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"Gutter-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"Gutter-1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"Gutter-1-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"Gutter-1-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"Gutter-1-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:21:"Gutter-1-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:22:"Gutter-1-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:20:"Gutter-1-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:22:"Gutter-1-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:13:"iPhone 6 Plus";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1436541060;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:19:"0.00063211125158028";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(68, 36, '_wp_attached_file', '2016/01/Gutter-2.jpeg'),
(69, 36, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:21:"2016/01/Gutter-2.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"Gutter-2-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"Gutter-2-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"Gutter-2-400x300.jpeg";s:5:"width";i:400;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:21:"Gutter-2-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(70, 37, '_wp_attached_file', '2016/01/Gutter-2.jpg'),
(71, 37, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:20:"2016/01/Gutter-2.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"Gutter-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"Gutter-2-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"Gutter-2-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"Gutter-2-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"Gutter-2-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:21:"Gutter-2-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:22:"Gutter-2-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:20:"Gutter-2-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:22:"Gutter-2-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452004909;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(72, 38, '_wp_attached_file', '2016/01/Gutter-after.jpeg'),
(73, 38, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:300;s:4:"file";s:25:"2016/01/Gutter-after.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Gutter-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Gutter-after-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Gutter-after-400x300.jpeg";s:5:"width";i:400;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:25:"Gutter-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(74, 39, '_wp_attached_file', '2016/01/Gutter-brush.jpg'),
(75, 39, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2448;s:6:"height";i:3264;s:4:"file";s:24:"2016/01/Gutter-brush.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Gutter-brush-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"Gutter-brush-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"Gutter-brush-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Gutter-brush-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"Gutter-brush-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:25:"Gutter-brush-800x3264.jpg";s:5:"width";i:800;s:6:"height";i:3264;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:26:"Gutter-brush-1080x3264.jpg";s:5:"width";i:1080;s:6:"height";i:3264;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:24:"Gutter-brush-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:26:"Gutter-brush-1200x3264.jpg";s:5:"width";i:1200;s:6:"height";i:3264;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:13:"iPhone 6 Plus";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1441712943;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:19:"0.00048007681228997";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(76, 40, '_wp_attached_file', '2016/01/House-after.jpg'),
(77, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:23:"2016/01/House-after.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"House-after-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"House-after-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"House-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"House-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"House-after-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:24:"House-after-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:25:"House-after-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:23:"House-after-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:25:"House-after-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:13:"iPhone 6 Plus";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1437993599;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:19:"0.00068306010928962";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(78, 41, '_wp_attached_file', '2016/01/House-before.jpg'),
(79, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2448;s:6:"height";i:3264;s:4:"file";s:24:"2016/01/House-before.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"House-before-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"House-before-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"House-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"House-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"House-before-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:25:"House-before-800x3264.jpg";s:5:"width";i:800;s:6:"height";i:3264;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:26:"House-before-1080x3264.jpg";s:5:"width";i:1080;s:6:"height";i:3264;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:24:"House-before-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:26:"House-before-1200x3264.jpg";s:5:"width";i:1200;s:6:"height";i:3264;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:13:"iPhone 6 Plus";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1437991215;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:19:"0.00090991810737034";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(80, 42, '_wp_attached_file', '2016/01/House-front.jpeg'),
(81, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:24:"2016/01/House-front.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"House-front-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"House-front-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"House-front-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"House-front-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"House-front-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:25:"House-front-800x1536.jpeg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:26:"House-front-1080x1536.jpeg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:24:"House-front-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:26:"House-front-1200x1536.jpeg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1397300156;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:19:"0.00072411296162201";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(82, 43, '_wp_attached_file', '2016/01/JC-after.jpeg'),
(83, 43, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:21:"2016/01/JC-after.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"JC-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"JC-after-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"JC-after-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"JC-after-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"JC-after-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:22:"JC-after-800x1536.jpeg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:23:"JC-after-1080x1536.jpeg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:21:"JC-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:23:"JC-after-1200x1536.jpeg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1394726935;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:18:"0.0011049723756906";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(84, 44, '_wp_attached_file', '2016/01/JC-before.jpeg'),
(85, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:22:"2016/01/JC-before.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"JC-before-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"JC-before-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"JC-before-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"JC-before-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"JC-before-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:23:"JC-before-800x1536.jpeg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:24:"JC-before-1080x1536.jpeg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:22:"JC-before-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:24:"JC-before-1200x1536.jpeg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1394725735;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:18:"0.0025252525252525";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(86, 45, '_wp_attached_file', '2016/01/JC-during.jpeg'),
(87, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:22:"2016/01/JC-during.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"JC-during-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"JC-during-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"JC-during-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"JC-during-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"JC-during-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:23:"JC-during-800x2048.jpeg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:24:"JC-during-1080x2048.jpeg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:22:"JC-during-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:24:"JC-during-1200x2048.jpeg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1394726619;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:18:"0.0018148820326679";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(88, 46, '_wp_attached_file', '2016/01/JC-steps-after.jpg'),
(89, 46, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:26:"2016/01/JC-steps-after.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"JC-steps-after-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"JC-steps-after-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"JC-steps-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"JC-steps-after-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"JC-steps-after-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:27:"JC-steps-after-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:28:"JC-steps-after-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:26:"JC-steps-after-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:28:"JC-steps-after-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1438187898;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(90, 47, '_wp_attached_file', '2016/01/JC-steps-before.jpg'),
(91, 47, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:27:"2016/01/JC-steps-before.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"JC-steps-before-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"JC-steps-before-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"JC-steps-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"JC-steps-before-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:27:"JC-steps-before-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:28:"JC-steps-before-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:29:"JC-steps-before-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:27:"JC-steps-before-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:29:"JC-steps-before-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1438187491;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(92, 48, '_wp_attached_file', '2016/01/Logo.jpeg'),
(93, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:498;s:6:"height";i:139;s:4:"file";s:17:"2016/01/Logo.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"Logo-150x139.jpeg";s:5:"width";i:150;s:6:"height";i:139;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"Logo-300x84.jpeg";s:5:"width";i:300;s:6:"height";i:84;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"Logo-400x139.jpeg";s:5:"width";i:400;s:6:"height";i:139;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:17:"Logo-140x139.jpeg";s:5:"width";i:140;s:6:"height";i:139;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(94, 49, '_wp_attached_file', '2016/01/Lot-31-stamped-1.jpg'),
(95, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:28:"2016/01/Lot-31-stamped-1.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-31-stamped-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-31-stamped-1-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"Lot-31-stamped-1-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-31-stamped-1-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-31-stamped-1-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-31-stamped-1-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-31-stamped-1-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-31-stamped-1-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-31-stamped-1-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448026484;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(96, 50, '_wp_attached_file', '2016/01/Lot-31-stamped-2.jpg'),
(97, 50, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:28:"2016/01/Lot-31-stamped-2.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-31-stamped-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-31-stamped-2-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"Lot-31-stamped-2-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-31-stamped-2-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-31-stamped-2-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-31-stamped-2-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-31-stamped-2-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-31-stamped-2-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-31-stamped-2-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448026492;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(98, 51, '_wp_attached_file', '2016/01/Lot-31-stamped-3.jpg'),
(99, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:28:"2016/01/Lot-31-stamped-3.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-31-stamped-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-31-stamped-3-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"Lot-31-stamped-3-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-31-stamped-3-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-31-stamped-3-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-31-stamped-3-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-31-stamped-3-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-31-stamped-3-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-31-stamped-3-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448026495;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(100, 52, '_wp_attached_file', '2016/01/Lot-31-stamped-full.jpg'),
(101, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:31:"2016/01/Lot-31-stamped-full.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"Lot-31-stamped-full-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"Lot-31-stamped-full-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"Lot-31-stamped-full-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"Lot-31-stamped-full-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:31:"Lot-31-stamped-full-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:32:"Lot-31-stamped-full-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:33:"Lot-31-stamped-full-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:31:"Lot-31-stamped-full-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:33:"Lot-31-stamped-full-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448035634;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(102, 53, '_wp_attached_file', '2016/01/Lot-32-stamped-1.jpg'),
(103, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:28:"2016/01/Lot-32-stamped-1.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-32-stamped-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-32-stamped-1-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"Lot-32-stamped-1-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-32-stamped-1-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-32-stamped-1-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-32-stamped-1-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-32-stamped-1-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-32-stamped-1-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-32-stamped-1-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448035659;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(104, 54, '_wp_attached_file', '2016/01/Lot-32-stamped-2.jpg'),
(105, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:28:"2016/01/Lot-32-stamped-2.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-32-stamped-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-32-stamped-2-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"Lot-32-stamped-2-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-32-stamped-2-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-32-stamped-2-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-32-stamped-2-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-32-stamped-2-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-32-stamped-2-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-32-stamped-2-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448035681;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(106, 55, '_wp_attached_file', '2016/01/Lot-32-stamped-3.jpg'),
(107, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:28:"2016/01/Lot-32-stamped-3.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-32-stamped-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-32-stamped-3-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"Lot-32-stamped-3-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-32-stamped-3-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-32-stamped-3-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-32-stamped-3-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-32-stamped-3-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-32-stamped-3-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-32-stamped-3-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448035692;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0067567567567568";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(108, 56, '_wp_attached_file', '2016/01/Lot-32-stamped-4.jpg'),
(109, 56, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:28:"2016/01/Lot-32-stamped-4.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-32-stamped-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-32-stamped-4-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"Lot-32-stamped-4-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-32-stamped-4-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-32-stamped-4-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-32-stamped-4-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-32-stamped-4-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-32-stamped-4-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-32-stamped-4-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448035702;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(110, 57, '_wp_attached_file', '2016/01/Lot-70-stamped-1.jpg'),
(111, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:28:"2016/01/Lot-70-stamped-1.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-70-stamped-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-70-stamped-1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"Lot-70-stamped-1-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-70-stamped-1-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-70-stamped-1-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-70-stamped-1-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-70-stamped-1-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-70-stamped-1-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-70-stamped-1-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1450536771;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(112, 58, '_wp_attached_file', '2016/01/Lot-97-stamped-1.jpg'),
(113, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:28:"2016/01/Lot-97-stamped-1.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-97-stamped-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-97-stamped-1-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"Lot-97-stamped-1-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-97-stamped-1-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-97-stamped-1-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-97-stamped-1-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-97-stamped-1-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-97-stamped-1-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-97-stamped-1-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448371268;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:19:"0.00083402835696414";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(114, 59, '_wp_attached_file', '2016/01/Lot-97-stamped-2.jpg'),
(115, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:28:"2016/01/Lot-97-stamped-2.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-97-stamped-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-97-stamped-2-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"Lot-97-stamped-2-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-97-stamped-2-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-97-stamped-2-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-97-stamped-2-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-97-stamped-2-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-97-stamped-2-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-97-stamped-2-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448373833;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:17:"0.001187648456057";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(116, 60, '_wp_attached_file', '2016/01/Lot-97-stamped-3.jpg'),
(117, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:28:"2016/01/Lot-97-stamped-3.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Lot-97-stamped-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Lot-97-stamped-3-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"Lot-97-stamped-3-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"Lot-97-stamped-3-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Lot-97-stamped-3-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Lot-97-stamped-3-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Lot-97-stamped-3-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Lot-97-stamped-3-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Lot-97-stamped-3-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1448373840;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0013157894736842";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(118, 61, '_wp_attached_file', '2016/01/North-harbor.jpeg'),
(119, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:25:"2016/01/North-harbor.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"North-harbor-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"North-harbor-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"North-harbor-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"North-harbor-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"North-harbor-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:26:"North-harbor-800x1632.jpeg";s:5:"width";i:800;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:27:"North-harbor-1080x1632.jpeg";s:5:"width";i:1080;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:25:"North-harbor-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:27:"North-harbor-1200x1632.jpeg";s:5:"width";i:1200;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1335168103;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"80";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(120, 62, '_wp_attached_file', '2016/01/Patio-staining.jpg'),
(121, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"file";s:26:"2016/01/Patio-staining.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Patio-staining-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Patio-staining-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"Patio-staining-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"Patio-staining-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"Patio-staining-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:27:"Patio-staining-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:28:"Patio-staining-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:26:"Patio-staining-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:28:"Patio-staining-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1450275781;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0026041666666667";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(122, 63, '_wp_attached_file', '2016/01/Pool-side.jpeg'),
(123, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:22:"2016/01/Pool-side.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"Pool-side-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"Pool-side-225x300.jpeg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"Pool-side-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"Pool-side-768x1024.jpeg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"Pool-side-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:23:"Pool-side-800x1632.jpeg";s:5:"width";i:800;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:24:"Pool-side-1080x1632.jpeg";s:5:"width";i:1080;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:22:"Pool-side-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:24:"Pool-side-1200x1632.jpeg";s:5:"width";i:1200;s:6:"height";i:1632;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1337079011;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"80";s:13:"shutter_speed";s:19:"0.00085106382978723";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(124, 64, '_wp_attached_file', '2016/01/Porch-after.jpeg'),
(125, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1632;s:6:"height";i:1224;s:4:"file";s:24:"2016/01/Porch-after.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Porch-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"Porch-after-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"Porch-after-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Porch-after-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"Porch-after-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:25:"Porch-after-800x1224.jpeg";s:5:"width";i:800;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:26:"Porch-after-1080x1224.jpeg";s:5:"width";i:1080;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:24:"Porch-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:26:"Porch-after-1200x1224.jpeg";s:5:"width";i:1200;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1334919663;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"80";s:13:"shutter_speed";s:18:"0.0083333333333333";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(126, 65, '_wp_attached_file', '2016/01/Porch-before.jpeg'),
(127, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1632;s:6:"height";i:1224;s:4:"file";s:25:"2016/01/Porch-before.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"Porch-before-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"Porch-before-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"Porch-before-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"Porch-before-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:25:"Porch-before-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:26:"Porch-before-800x1224.jpeg";s:5:"width";i:800;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:27:"Porch-before-1080x1224.jpeg";s:5:"width";i:1080;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:25:"Porch-before-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:27:"Porch-before-1200x1224.jpeg";s:5:"width";i:1200;s:6:"height";i:1224;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.3999999999999999;s:6:"credit";s:0:"";s:6:"camera";s:9:"iPhone 4S";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1334917567;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.28";s:3:"iso";s:2:"64";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";s:11:"orientation";i:1;s:8:"keywords";a:0:{}}}'),
(128, 66, '_wp_attached_file', '2016/01/Retaining-wall.jpg'),
(129, 66, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:26:"2016/01/Retaining-wall.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Retaining-wall-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"Retaining-wall-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"Retaining-wall-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"Retaining-wall-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:26:"Retaining-wall-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:27:"Retaining-wall-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:28:"Retaining-wall-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:26:"Retaining-wall-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:28:"Retaining-wall-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1443096317;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0034364261168385";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(130, 67, '_wp_attached_file', '2016/01/Rust-after.jpeg'),
(131, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:23:"2016/01/Rust-after.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"Rust-after-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"Rust-after-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"Rust-after-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"Rust-after-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:23:"Rust-after-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:24:"Rust-after-800x1536.jpeg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:25:"Rust-after-1080x1536.jpeg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:23:"Rust-after-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:25:"Rust-after-1200x1536.jpeg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:13:"iPhone 6 Plus";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1431095429;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0038910505836576";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(132, 68, '_wp_attached_file', '2016/01/Rust-before.jpeg'),
(133, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:24:"2016/01/Rust-before.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Rust-before-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"Rust-before-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"Rust-before-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Rust-before-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:24:"Rust-before-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:25:"Rust-before-800x1536.jpeg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:26:"Rust-before-1080x1536.jpeg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:24:"Rust-before-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:26:"Rust-before-1200x1536.jpeg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:13:"iPhone 6 Plus";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1431093748;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0027855153203343";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(134, 69, '_wp_attached_file', '2016/01/Sidewalk.jpg'),
(135, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:20:"2016/01/Sidewalk.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"Sidewalk-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"Sidewalk-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"Sidewalk-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"Sidewalk-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"Sidewalk-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:21:"Sidewalk-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:22:"Sidewalk-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:20:"Sidewalk-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:22:"Sidewalk-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1445860203;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"40";s:13:"shutter_speed";s:5:"0.025";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(136, 70, '_wp_attached_file', '2016/01/Sidewalk-2.jpg'),
(137, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:22:"2016/01/Sidewalk-2.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"Sidewalk-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"Sidewalk-2-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"Sidewalk-2-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"Sidewalk-2-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"Sidewalk-2-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:23:"Sidewalk-2-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:24:"Sidewalk-2-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:22:"Sidewalk-2-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:24:"Sidewalk-2-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1452005586;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(138, 71, '_wp_attached_file', '2016/01/Southcreek-trucks.jpeg'),
(139, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"file";s:30:"2016/01/Southcreek-trucks.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"Southcreek-trucks-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:30:"Southcreek-trucks-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"Southcreek-trucks-768x768.jpeg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"Southcreek-trucks-1024x1024.jpeg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:30:"Southcreek-trucks-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:31:"Southcreek-trucks-800x2048.jpeg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:32:"Southcreek-trucks-1080x2048.jpeg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:30:"Southcreek-trucks-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:32:"Southcreek-trucks-1200x2048.jpeg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1435494936;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:19:"0.00035398230088496";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(140, 72, '_wp_attached_file', '2016/01/Stamped-sealing.jpeg'),
(141, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"file";s:28:"2016/01/Stamped-sealing.jpeg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"Stamped-sealing-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"Stamped-sealing-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"Stamped-sealing-768x768.jpeg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"Stamped-sealing-1024x1024.jpeg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"Stamped-sealing-400x350.jpeg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:29:"Stamped-sealing-800x2048.jpeg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:30:"Stamped-sealing-1080x2048.jpeg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:28:"Stamped-sealing-140x140.jpeg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:30:"Stamped-sealing-1200x2048.jpeg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1431591410;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:18:"0.0022779043280182";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(142, 73, '_wp_attached_file', '2016/01/Vinyl-dock.jpg'),
(143, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:22:"2016/01/Vinyl-dock.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"Vinyl-dock-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"Vinyl-dock-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"Vinyl-dock-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"Vinyl-dock-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:22:"Vinyl-dock-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:23:"Vinyl-dock-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:24:"Vinyl-dock-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:22:"Vinyl-dock-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:24:"Vinyl-dock-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1438174387;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:19:"0.00035398230088496";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(144, 74, '_wp_attached_file', '2016/01/Vinyl-fence-2-after.jpg'),
(145, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1536;s:4:"file";s:31:"2016/01/Vinyl-fence-2-after.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"Vinyl-fence-2-after-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"Vinyl-fence-2-after-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"Vinyl-fence-2-after-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"Vinyl-fence-2-after-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:31:"Vinyl-fence-2-after-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:32:"Vinyl-fence-2-after-800x1536.jpg";s:5:"width";i:800;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:33:"Vinyl-fence-2-after-1080x1536.jpg";s:5:"width";i:1080;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:31:"Vinyl-fence-2-after-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:33:"Vinyl-fence-2-after-1200x1536.jpg";s:5:"width";i:1200;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:13:"iPhone 6 Plus";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1449075719;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"50";s:13:"shutter_speed";s:17:"0.066666666666667";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(146, 75, '_wp_attached_file', '2016/01/Wood-dock.jpg'),
(147, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1536;s:6:"height";i:2048;s:4:"file";s:21:"2016/01/Wood-dock.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"Wood-dock-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"Wood-dock-225x300.jpg";s:5:"width";i:225;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"Wood-dock-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"Wood-dock-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"Wood-dock-400x350.jpg";s:5:"width";i:400;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-aside";a:4:{s:4:"file";s:22:"Wood-dock-800x2048.jpg";s:5:"width";i:800;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:15:"corpobox-medium";a:4:{s:4:"file";s:23:"Wood-dock-1080x2048.jpg";s:5:"width";i:1080;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}s:14:"corpobox-small";a:4:{s:4:"file";s:21:"Wood-dock-140x140.jpg";s:5:"width";i:140;s:6:"height";i:140;s:9:"mime-type";s:10:"image/jpeg";}s:12:"corpobox-big";a:4:{s:4:"file";s:23:"Wood-dock-1200x2048.jpg";s:5:"width";i:1200;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";d:2.2000000000000002;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 6";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1442937114;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"4.15";s:3:"iso";s:2:"32";s:13:"shutter_speed";s:19:"0.00090991810737034";s:5:"title";s:0:"";s:11:"orientation";i:0;s:8:"keywords";a:0:{}}}'),
(148, 2, '_wp_trash_meta_status', 'publish'),
(149, 2, '_wp_trash_meta_time', '1452828546'),
(150, 77, '_edit_last', '1'),
(151, 77, '_edit_lock', '1454293893:1'),
(152, 77, '_wp_page_template', 'template-home-main.php'),
(153, 79, '_menu_item_type', 'post_type'),
(154, 79, '_menu_item_menu_item_parent', '0'),
(155, 79, '_menu_item_object_id', '77'),
(156, 79, '_menu_item_object', 'page'),
(157, 79, '_menu_item_target', ''),
(158, 79, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(159, 79, '_menu_item_xfn', ''),
(160, 79, '_menu_item_url', ''),
(161, 82, '_edit_last', '1'),
(162, 82, '_wp_page_template', 'default'),
(163, 82, '_edit_lock', '1454293963:1'),
(164, 84, '_edit_last', '1'),
(165, 84, '_wp_page_template', 'default'),
(166, 84, '_edit_lock', '1454293951:1'),
(167, 87, '_edit_last', '1'),
(168, 87, '_wp_page_template', 'default'),
(169, 87, '_edit_lock', '1454293944:1'),
(170, 89, '_edit_last', '1'),
(171, 89, '_wp_page_template', 'default'),
(172, 89, '_edit_lock', '1454293960:1'),
(173, 91, '_edit_last', '1'),
(174, 91, '_wp_page_template', 'default'),
(175, 91, '_edit_lock', '1454293956:1'),
(176, 95, '_menu_item_type', 'post_type'),
(177, 95, '_menu_item_menu_item_parent', '0'),
(178, 95, '_menu_item_object_id', '82'),
(179, 95, '_menu_item_object', 'page'),
(180, 95, '_menu_item_target', ''),
(181, 95, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(182, 95, '_menu_item_xfn', ''),
(183, 95, '_menu_item_url', ''),
(185, 96, '_menu_item_type', 'post_type'),
(186, 96, '_menu_item_menu_item_parent', '0'),
(187, 96, '_menu_item_object_id', '89'),
(188, 96, '_menu_item_object', 'page'),
(189, 96, '_menu_item_target', ''),
(190, 96, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(191, 96, '_menu_item_xfn', ''),
(192, 96, '_menu_item_url', ''),
(194, 97, '_menu_item_type', 'post_type'),
(195, 97, '_menu_item_menu_item_parent', '0'),
(196, 97, '_menu_item_object_id', '91'),
(197, 97, '_menu_item_object', 'page'),
(198, 97, '_menu_item_target', ''),
(199, 97, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(200, 97, '_menu_item_xfn', ''),
(201, 97, '_menu_item_url', ''),
(203, 98, '_menu_item_type', 'post_type'),
(204, 98, '_menu_item_menu_item_parent', '0'),
(205, 98, '_menu_item_object_id', '84'),
(206, 98, '_menu_item_object', 'page') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(207, 98, '_menu_item_target', ''),
(208, 98, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(209, 98, '_menu_item_xfn', ''),
(210, 98, '_menu_item_url', ''),
(212, 99, '_menu_item_type', 'post_type'),
(213, 99, '_menu_item_menu_item_parent', '0'),
(214, 99, '_menu_item_object_id', '87'),
(215, 99, '_menu_item_object', 'page'),
(216, 99, '_menu_item_target', ''),
(217, 99, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(218, 99, '_menu_item_xfn', ''),
(219, 99, '_menu_item_url', '') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(2, 1, '2016-01-15 03:09:00', '2016-01-15 03:09:00', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page', '', '', '2016-01-15 03:29:06', '2016-01-15 03:29:06', '', 0, 'http://localhost/?page_id=2', 0, 'page', '', 0),
(5, 1, '2016-01-15 03:21:39', '2016-01-15 03:21:39', '', 'apw_logo1', '', 'inherit', 'open', 'closed', '', 'apw_logo1', '', '', '2016-01-15 03:21:39', '2016-01-15 03:21:39', '', 0, 'http://localhost/wp-content/uploads/2016/01/apw_logo1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(6, 1, '2016-01-15 03:24:10', '2016-01-15 03:24:10', '', 'Apt left side after', '', 'inherit', 'open', 'closed', '', 'apt-left-side-after', '', '', '2016-01-15 03:24:10', '2016-01-15 03:24:10', '', 0, 'http://localhost/wp-content/uploads/2016/01/Apt-left-side-after.jpg', 0, 'attachment', 'image/jpeg', 0),
(7, 1, '2016-01-15 03:24:11', '2016-01-15 03:24:11', '', 'Apt left side before', '', 'inherit', 'open', 'closed', '', 'apt-left-side-before', '', '', '2016-01-15 03:24:11', '2016-01-15 03:24:11', '', 0, 'http://localhost/wp-content/uploads/2016/01/Apt-left-side-before.jpg', 0, 'attachment', 'image/jpeg', 0),
(8, 1, '2016-01-15 03:24:11', '2016-01-15 03:24:11', '', 'Apt right side after', '', 'inherit', 'open', 'closed', '', 'apt-right-side-after', '', '', '2016-01-15 03:24:11', '2016-01-15 03:24:11', '', 0, 'http://localhost/wp-content/uploads/2016/01/Apt-right-side-after.jpg', 0, 'attachment', 'image/jpeg', 0),
(9, 1, '2016-01-15 03:24:12', '2016-01-15 03:24:12', '', 'Apt right side before', '', 'inherit', 'open', 'closed', '', 'apt-right-side-before', '', '', '2016-01-15 03:24:12', '2016-01-15 03:24:12', '', 0, 'http://localhost/wp-content/uploads/2016/01/Apt-right-side-before.jpg', 0, 'attachment', 'image/jpeg', 0),
(10, 1, '2016-01-15 03:24:12', '2016-01-15 03:24:12', '', 'Bobcat after', '', 'inherit', 'open', 'closed', '', 'bobcat-after', '', '', '2016-01-15 03:24:12', '2016-01-15 03:24:12', '', 0, 'http://localhost/wp-content/uploads/2016/01/Bobcat-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(11, 1, '2016-01-15 03:24:13', '2016-01-15 03:24:13', '', 'Bobcat before', '', 'inherit', 'open', 'closed', '', 'bobcat-before', '', '', '2016-01-15 03:24:13', '2016-01-15 03:24:13', '', 0, 'http://localhost/wp-content/uploads/2016/01/Bobcat-before.jpeg', 0, 'attachment', 'image/jpeg', 0),
(12, 1, '2016-01-15 03:24:13', '2016-01-15 03:24:13', '', 'Brick after', '', 'inherit', 'open', 'closed', '', 'brick-after', '', '', '2016-01-15 03:24:13', '2016-01-15 03:24:13', '', 0, 'http://localhost/wp-content/uploads/2016/01/Brick-after.jpg', 0, 'attachment', 'image/jpeg', 0),
(13, 1, '2016-01-15 03:24:14', '2016-01-15 03:24:14', '', 'Brick before', '', 'inherit', 'open', 'closed', '', 'brick-before', '', '', '2016-01-15 03:24:14', '2016-01-15 03:24:14', '', 0, 'http://localhost/wp-content/uploads/2016/01/Brick-before.jpg', 0, 'attachment', 'image/jpeg', 0),
(14, 1, '2016-01-15 03:24:14', '2016-01-15 03:24:14', '', 'Brick patio', '', 'inherit', 'open', 'closed', '', 'brick-patio', '', '', '2016-01-15 03:24:14', '2016-01-15 03:24:14', '', 0, 'http://localhost/wp-content/uploads/2016/01/Brick-patio.jpg', 0, 'attachment', 'image/jpeg', 0),
(15, 1, '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 'Cedar house after', '', 'inherit', 'open', 'closed', '', 'cedar-house-after', '', '', '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 0, 'http://localhost/wp-content/uploads/2016/01/Cedar-house-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 'Cedar house before', '', 'inherit', 'open', 'closed', '', 'cedar-house-before', '', '', '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 0, 'http://localhost/wp-content/uploads/2016/01/Cedar-house-before.jpeg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 'Cedar house side by side', '', 'inherit', 'open', 'closed', '', 'cedar-house-side-by-side', '', '', '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 0, 'http://localhost/wp-content/uploads/2016/01/Cedar-house-side-by-side.jpeg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 'Cement', '', 'inherit', 'open', 'closed', '', 'cement', '', '', '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 0, 'http://localhost/wp-content/uploads/2016/01/Cement.jpeg', 0, 'attachment', 'image/jpeg', 0),
(19, 1, '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 'Cement beforeafter', '', 'inherit', 'open', 'closed', '', 'cement-beforeafter', '', '', '2016-01-15 03:24:15', '2016-01-15 03:24:15', '', 0, 'http://localhost/wp-content/uploads/2016/01/Cement-beforeafter.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2016-01-15 03:24:16', '2016-01-15 03:24:16', '', 'Cement steps', '', 'inherit', 'open', 'closed', '', 'cement-steps', '', '', '2016-01-15 03:24:16', '2016-01-15 03:24:16', '', 0, 'http://localhost/wp-content/uploads/2016/01/Cement-steps.jpg', 0, 'attachment', 'image/jpeg', 0),
(21, 1, '2016-01-15 03:24:16', '2016-01-15 03:24:16', '', 'Deck', '', 'inherit', 'open', 'closed', '', 'deck', '', '', '2016-01-15 03:24:16', '2016-01-15 03:24:16', '', 0, 'http://localhost/wp-content/uploads/2016/01/Deck.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2016-01-15 03:24:17', '2016-01-15 03:24:17', '', 'Deck after', '', 'inherit', 'open', 'closed', '', 'deck-after', '', '', '2016-01-15 03:24:17', '2016-01-15 03:24:17', '', 0, 'http://localhost/wp-content/uploads/2016/01/Deck-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(23, 1, '2016-01-15 03:24:17', '2016-01-15 03:24:17', '', 'Deck after 2', '', 'inherit', 'open', 'closed', '', 'deck-after-2', '', '', '2016-01-15 03:24:17', '2016-01-15 03:24:17', '', 0, 'http://localhost/wp-content/uploads/2016/01/Deck-after-2.jpeg', 0, 'attachment', 'image/jpeg', 0),
(24, 1, '2016-01-15 03:24:18', '2016-01-15 03:24:18', '', 'Deck before', '', 'inherit', 'open', 'closed', '', 'deck-before', '', '', '2016-01-15 03:24:18', '2016-01-15 03:24:18', '', 0, 'http://localhost/wp-content/uploads/2016/01/Deck-before.jpeg', 0, 'attachment', 'image/jpeg', 0),
(25, 1, '2016-01-15 03:24:18', '2016-01-15 03:24:18', '', 'Deck cleaning', '', 'inherit', 'open', 'closed', '', 'deck-cleaning', '', '', '2016-01-15 03:24:18', '2016-01-15 03:24:18', '', 0, 'http://localhost/wp-content/uploads/2016/01/Deck-cleaning.jpeg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2016-01-15 03:24:19', '2016-01-15 03:24:19', '', 'Denver truck fleet', '', 'inherit', 'open', 'closed', '', 'denver-truck-fleet', '', '', '2016-01-15 03:24:19', '2016-01-15 03:24:19', '', 0, 'http://localhost/wp-content/uploads/2016/01/Denver-truck-fleet.jpeg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2016-01-15 03:24:19', '2016-01-15 03:24:19', '', 'Dock', '', 'inherit', 'open', 'closed', '', 'dock', '', '', '2016-01-15 03:24:19', '2016-01-15 03:24:19', '', 0, 'http://localhost/wp-content/uploads/2016/01/Dock.jpeg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2016-01-15 03:24:20', '2016-01-15 03:24:20', '', 'Driveway', '', 'inherit', 'open', 'closed', '', 'driveway', '', '', '2016-01-15 03:24:20', '2016-01-15 03:24:20', '', 0, 'http://localhost/wp-content/uploads/2016/01/Driveway.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2016-01-15 03:24:20', '2016-01-15 03:24:20', '', 'Driveway after', '', 'inherit', 'open', 'closed', '', 'driveway-after', '', '', '2016-01-15 03:24:20', '2016-01-15 03:24:20', '', 0, 'http://localhost/wp-content/uploads/2016/01/Driveway-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(30, 1, '2016-01-15 03:24:21', '2016-01-15 03:24:21', '', 'Driveway before', '', 'inherit', 'open', 'closed', '', 'driveway-before', '', '', '2016-01-15 03:24:21', '2016-01-15 03:24:21', '', 0, 'http://localhost/wp-content/uploads/2016/01/Driveway-before.jpeg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2016-01-15 03:24:21', '2016-01-15 03:24:21', '', 'Equipment', '', 'inherit', 'open', 'closed', '', 'equipment', '', '', '2016-01-15 03:24:21', '2016-01-15 03:24:21', '', 0, 'http://localhost/wp-content/uploads/2016/01/Equipment.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2016-01-15 03:24:23', '2016-01-15 03:24:23', '', 'Garage after', '', 'inherit', 'open', 'closed', '', 'garage-after', '', '', '2016-01-15 03:24:23', '2016-01-15 03:24:23', '', 0, 'http://localhost/wp-content/uploads/2016/01/Garage-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(33, 1, '2016-01-15 03:24:24', '2016-01-15 03:24:24', '', 'Garage before', '', 'inherit', 'open', 'closed', '', 'garage-before', '', '', '2016-01-15 03:24:24', '2016-01-15 03:24:24', '', 0, 'http://localhost/wp-content/uploads/2016/01/Garage-before.jpeg', 0, 'attachment', 'image/jpeg', 0),
(34, 1, '2016-01-15 03:24:25', '2016-01-15 03:24:25', '', 'Garage sealing', '', 'inherit', 'open', 'closed', '', 'garage-sealing', '', '', '2016-01-15 03:24:25', '2016-01-15 03:24:25', '', 0, 'http://localhost/wp-content/uploads/2016/01/Garage-sealing.jpeg', 0, 'attachment', 'image/jpeg', 0),
(35, 1, '2016-01-15 03:24:26', '2016-01-15 03:24:26', '', 'Gutter 1', '', 'inherit', 'open', 'closed', '', 'gutter-1', '', '', '2016-01-15 03:24:26', '2016-01-15 03:24:26', '', 0, 'http://localhost/wp-content/uploads/2016/01/Gutter-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(36, 1, '2016-01-15 03:24:27', '2016-01-15 03:24:27', '', 'Gutter 2', '', 'inherit', 'open', 'closed', '', 'gutter-2', '', '', '2016-01-15 03:24:27', '2016-01-15 03:24:27', '', 0, 'http://localhost/wp-content/uploads/2016/01/Gutter-2.jpeg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2016-01-15 03:24:28', '2016-01-15 03:24:28', '', 'Gutter 2', '', 'inherit', 'open', 'closed', '', 'gutter-2-2', '', '', '2016-01-15 03:24:28', '2016-01-15 03:24:28', '', 0, 'http://localhost/wp-content/uploads/2016/01/Gutter-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(38, 1, '2016-01-15 03:24:29', '2016-01-15 03:24:29', '', 'Gutter after', '', 'inherit', 'open', 'closed', '', 'gutter-after', '', '', '2016-01-15 03:24:29', '2016-01-15 03:24:29', '', 0, 'http://localhost/wp-content/uploads/2016/01/Gutter-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(39, 1, '2016-01-15 03:24:30', '2016-01-15 03:24:30', '', 'Gutter brush', '', 'inherit', 'open', 'closed', '', 'gutter-brush', '', '', '2016-01-15 03:24:30', '2016-01-15 03:24:30', '', 0, 'http://localhost/wp-content/uploads/2016/01/Gutter-brush.jpg', 0, 'attachment', 'image/jpeg', 0),
(40, 1, '2016-01-15 03:24:31', '2016-01-15 03:24:31', '', 'House after', '', 'inherit', 'open', 'closed', '', 'house-after', '', '', '2016-01-15 03:24:31', '2016-01-15 03:24:31', '', 0, 'http://localhost/wp-content/uploads/2016/01/House-after.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2016-01-15 03:24:32', '2016-01-15 03:24:32', '', 'House before', '', 'inherit', 'open', 'closed', '', 'house-before', '', '', '2016-01-15 03:24:32', '2016-01-15 03:24:32', '', 0, 'http://localhost/wp-content/uploads/2016/01/House-before.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2016-01-15 03:24:33', '2016-01-15 03:24:33', '', 'House front', '', 'inherit', 'open', 'closed', '', 'house-front', '', '', '2016-01-15 03:24:33', '2016-01-15 03:24:33', '', 0, 'http://localhost/wp-content/uploads/2016/01/House-front.jpeg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2016-01-15 03:24:34', '2016-01-15 03:24:34', '', 'JC after', '', 'inherit', 'open', 'closed', '', 'jc-after', '', '', '2016-01-15 03:24:34', '2016-01-15 03:24:34', '', 0, 'http://localhost/wp-content/uploads/2016/01/JC-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2016-01-15 03:24:35', '2016-01-15 03:24:35', '', 'JC before', '', 'inherit', 'open', 'closed', '', 'jc-before', '', '', '2016-01-15 03:24:35', '2016-01-15 03:24:35', '', 0, 'http://localhost/wp-content/uploads/2016/01/JC-before.jpeg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2016-01-15 03:24:36', '2016-01-15 03:24:36', '', 'JC during', '', 'inherit', 'open', 'closed', '', 'jc-during', '', '', '2016-01-15 03:24:36', '2016-01-15 03:24:36', '', 0, 'http://localhost/wp-content/uploads/2016/01/JC-during.jpeg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2016-01-15 03:24:37', '2016-01-15 03:24:37', '', 'JC steps after', '', 'inherit', 'open', 'closed', '', 'jc-steps-after', '', '', '2016-01-15 03:24:37', '2016-01-15 03:24:37', '', 0, 'http://localhost/wp-content/uploads/2016/01/JC-steps-after.jpg', 0, 'attachment', 'image/jpeg', 0),
(47, 1, '2016-01-15 03:24:38', '2016-01-15 03:24:38', '', 'JC steps before', '', 'inherit', 'open', 'closed', '', 'jc-steps-before', '', '', '2016-01-15 03:24:38', '2016-01-15 03:24:38', '', 0, 'http://localhost/wp-content/uploads/2016/01/JC-steps-before.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2016-01-15 03:24:39', '2016-01-15 03:24:39', '', 'Logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2016-01-15 03:24:39', '2016-01-15 03:24:39', '', 0, 'http://localhost/wp-content/uploads/2016/01/Logo.jpeg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2016-01-15 03:24:40', '2016-01-15 03:24:40', '', 'Lot 31 stamped 1', '', 'inherit', 'open', 'closed', '', 'lot-31-stamped-1', '', '', '2016-01-15 03:24:40', '2016-01-15 03:24:40', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-31-stamped-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2016-01-15 03:24:41', '2016-01-15 03:24:41', '', 'Lot 31 stamped 2', '', 'inherit', 'open', 'closed', '', 'lot-31-stamped-2', '', '', '2016-01-15 03:24:41', '2016-01-15 03:24:41', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-31-stamped-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2016-01-15 03:24:42', '2016-01-15 03:24:42', '', 'Lot 31 stamped 3', '', 'inherit', 'open', 'closed', '', 'lot-31-stamped-3', '', '', '2016-01-15 03:24:42', '2016-01-15 03:24:42', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-31-stamped-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2016-01-15 03:24:43', '2016-01-15 03:24:43', '', 'Lot 31 stamped full', '', 'inherit', 'open', 'closed', '', 'lot-31-stamped-full', '', '', '2016-01-15 03:24:43', '2016-01-15 03:24:43', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-31-stamped-full.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2016-01-15 03:24:44', '2016-01-15 03:24:44', '', 'Lot 32 stamped 1', '', 'inherit', 'open', 'closed', '', 'lot-32-stamped-1', '', '', '2016-01-15 03:24:44', '2016-01-15 03:24:44', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-32-stamped-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2016-01-15 03:24:45', '2016-01-15 03:24:45', '', 'Lot 32 stamped 2', '', 'inherit', 'open', 'closed', '', 'lot-32-stamped-2', '', '', '2016-01-15 03:24:45', '2016-01-15 03:24:45', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-32-stamped-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2016-01-15 03:24:46', '2016-01-15 03:24:46', '', 'Lot 32 stamped 3', '', 'inherit', 'open', 'closed', '', 'lot-32-stamped-3', '', '', '2016-01-15 03:24:46', '2016-01-15 03:24:46', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-32-stamped-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2016-01-15 03:24:47', '2016-01-15 03:24:47', '', 'Lot 32 stamped 4', '', 'inherit', 'open', 'closed', '', 'lot-32-stamped-4', '', '', '2016-01-15 03:24:47', '2016-01-15 03:24:47', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-32-stamped-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2016-01-15 03:24:48', '2016-01-15 03:24:48', '', 'Lot 70 stamped 1', '', 'inherit', 'open', 'closed', '', 'lot-70-stamped-1', '', '', '2016-01-15 03:24:48', '2016-01-15 03:24:48', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-70-stamped-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2016-01-15 03:24:49', '2016-01-15 03:24:49', '', 'Lot 97 stamped 1', '', 'inherit', 'open', 'closed', '', 'lot-97-stamped-1', '', '', '2016-01-15 03:24:49', '2016-01-15 03:24:49', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-97-stamped-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2016-01-15 03:24:49', '2016-01-15 03:24:49', '', 'Lot 97 stamped 2', '', 'inherit', 'open', 'closed', '', 'lot-97-stamped-2', '', '', '2016-01-15 03:24:49', '2016-01-15 03:24:49', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-97-stamped-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2016-01-15 03:24:50', '2016-01-15 03:24:50', '', 'Lot 97 stamped 3', '', 'inherit', 'open', 'closed', '', 'lot-97-stamped-3', '', '', '2016-01-15 03:24:50', '2016-01-15 03:24:50', '', 0, 'http://localhost/wp-content/uploads/2016/01/Lot-97-stamped-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2016-01-15 03:24:50', '2016-01-15 03:24:50', '', 'North harbor', '', 'inherit', 'open', 'closed', '', 'north-harbor', '', '', '2016-01-15 03:24:50', '2016-01-15 03:24:50', '', 0, 'http://localhost/wp-content/uploads/2016/01/North-harbor.jpeg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2016-01-15 03:24:51', '2016-01-15 03:24:51', '', 'Patio staining', '', 'inherit', 'open', 'closed', '', 'patio-staining', '', '', '2016-01-15 03:24:51', '2016-01-15 03:24:51', '', 0, 'http://localhost/wp-content/uploads/2016/01/Patio-staining.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2016-01-15 03:24:51', '2016-01-15 03:24:51', '', 'Pool side', '', 'inherit', 'open', 'closed', '', 'pool-side', '', '', '2016-01-15 03:24:51', '2016-01-15 03:24:51', '', 0, 'http://localhost/wp-content/uploads/2016/01/Pool-side.jpeg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2016-01-15 03:24:52', '2016-01-15 03:24:52', '', 'Porch after', '', 'inherit', 'open', 'closed', '', 'porch-after', '', '', '2016-01-15 03:24:52', '2016-01-15 03:24:52', '', 0, 'http://localhost/wp-content/uploads/2016/01/Porch-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(65, 1, '2016-01-15 03:24:52', '2016-01-15 03:24:52', '', 'Porch before', '', 'inherit', 'open', 'closed', '', 'porch-before', '', '', '2016-01-15 03:24:52', '2016-01-15 03:24:52', '', 0, 'http://localhost/wp-content/uploads/2016/01/Porch-before.jpeg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2016-01-15 03:24:53', '2016-01-15 03:24:53', '', 'Retaining wall', '', 'inherit', 'open', 'closed', '', 'retaining-wall', '', '', '2016-01-15 03:24:53', '2016-01-15 03:24:53', '', 0, 'http://localhost/wp-content/uploads/2016/01/Retaining-wall.jpg', 0, 'attachment', 'image/jpeg', 0),
(67, 1, '2016-01-15 03:24:53', '2016-01-15 03:24:53', '', 'Rust after', '', 'inherit', 'open', 'closed', '', 'rust-after', '', '', '2016-01-15 03:24:53', '2016-01-15 03:24:53', '', 0, 'http://localhost/wp-content/uploads/2016/01/Rust-after.jpeg', 0, 'attachment', 'image/jpeg', 0),
(68, 1, '2016-01-15 03:24:54', '2016-01-15 03:24:54', '', 'Rust before', '', 'inherit', 'open', 'closed', '', 'rust-before', '', '', '2016-01-15 03:24:54', '2016-01-15 03:24:54', '', 0, 'http://localhost/wp-content/uploads/2016/01/Rust-before.jpeg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2016-01-15 03:24:54', '2016-01-15 03:24:54', '', 'Sidewalk', '', 'inherit', 'open', 'closed', '', 'sidewalk', '', '', '2016-01-15 03:24:54', '2016-01-15 03:24:54', '', 0, 'http://localhost/wp-content/uploads/2016/01/Sidewalk.jpg', 0, 'attachment', 'image/jpeg', 0),
(70, 1, '2016-01-15 03:24:55', '2016-01-15 03:24:55', '', 'Sidewalk 2', '', 'inherit', 'open', 'closed', '', 'sidewalk-2', '', '', '2016-01-15 03:24:55', '2016-01-15 03:24:55', '', 0, 'http://localhost/wp-content/uploads/2016/01/Sidewalk-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(71, 1, '2016-01-15 03:24:55', '2016-01-15 03:24:55', '', 'Southcreek trucks', '', 'inherit', 'open', 'closed', '', 'southcreek-trucks', '', '', '2016-01-15 03:24:55', '2016-01-15 03:24:55', '', 0, 'http://localhost/wp-content/uploads/2016/01/Southcreek-trucks.jpeg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2016-01-15 03:24:56', '2016-01-15 03:24:56', '', 'Stamped sealing', '', 'inherit', 'open', 'closed', '', 'stamped-sealing', '', '', '2016-01-15 03:24:56', '2016-01-15 03:24:56', '', 0, 'http://localhost/wp-content/uploads/2016/01/Stamped-sealing.jpeg', 0, 'attachment', 'image/jpeg', 0),
(73, 1, '2016-01-15 03:24:56', '2016-01-15 03:24:56', '', 'Vinyl dock', '', 'inherit', 'open', 'closed', '', 'vinyl-dock', '', '', '2016-01-15 03:24:56', '2016-01-15 03:24:56', '', 0, 'http://localhost/wp-content/uploads/2016/01/Vinyl-dock.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2016-01-15 03:24:57', '2016-01-15 03:24:57', '', 'Vinyl fence 2 after', '', 'inherit', 'open', 'closed', '', 'vinyl-fence-2-after', '', '', '2016-01-15 03:24:57', '2016-01-15 03:24:57', '', 0, 'http://localhost/wp-content/uploads/2016/01/Vinyl-fence-2-after.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2016-01-15 03:24:57', '2016-01-15 03:24:57', '', 'Wood dock', '', 'inherit', 'open', 'closed', '', 'wood-dock', '', '', '2016-01-15 03:24:57', '2016-01-15 03:24:57', '', 0, 'http://localhost/wp-content/uploads/2016/01/Wood-dock.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2016-01-15 03:29:06', '2016-01-15 03:29:06', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-01-15 03:29:06', '2016-01-15 03:29:06', '', 2, 'http://localhost/index.php/2016/01/15/2-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2016-01-15 03:29:27', '2016-01-15 03:29:27', '<span style="font-family: \'Times New Roman\', serif;"><span style="font-size: medium;">Our goal is to provide excellent pressure washing services at an affordable price. We are locally owned and fully licensed and insured with over 10 years of experience. Our service area includes the Charlotte Metropolitan and Lake Norman areas. We look forward to taking care of your residential or commercial pressure washing needs. Check us out on Angie’s List for more reviews.</span></span>', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2016-01-15 03:35:28', '2016-01-15 03:35:28', '', 0, 'http://localhost/?page_id=77', 0, 'page', '', 0),
(78, 1, '2016-01-15 03:29:25', '2016-01-15 03:29:25', 'This will be the homepage', 'Home', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2016-01-15 03:29:25', '2016-01-15 03:29:25', '', 77, 'http://localhost/index.php/2016/01/15/77-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2016-01-15 03:32:01', '2016-01-15 03:32:01', ' ', '', '', 'publish', 'closed', 'closed', '', '79', '', '', '2016-02-01 02:36:07', '2016-02-01 02:36:07', '', 0, 'http://localhost/index.php/2016/01/15/79/', 1, 'nav_menu_item', '', 0),
(80, 1, '2016-01-15 03:35:14', '2016-01-15 03:35:14', '<span style="font-family: \'Times New Roman\', serif;"><span style="font-size: medium;">Our goal is to provide excellent pressure washing services at an affordable price. We are locally owned and fully licensed and insured with over 10 years of experience. Our service area includes the Charlotte Metropolitan and Lake Norman areas. We look forward to taking care of your residential or commercial pressure washing needs. Check us out on Angie’s List for more reviews.</span></span>', 'Home', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2016-01-15 03:35:14', '2016-01-15 03:35:14', '', 77, 'http://localhost/index.php/2016/01/15/77-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2016-02-01 02:28:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-02-01 02:28:27', '0000-00-00 00:00:00', '', 0, 'http://localhost/?p=81', 0, 'post', '', 0),
(82, 1, '2016-02-01 02:35:07', '2016-02-01 02:35:07', '', 'What We Do', '', 'publish', 'closed', 'closed', '', 'what-we-do', '', '', '2016-02-01 02:35:07', '2016-02-01 02:35:07', '', 0, 'http://localhost/?page_id=82', 0, 'page', '', 0),
(83, 1, '2016-02-01 02:28:39', '2016-02-01 02:28:39', '', 'Our Work', '', 'inherit', 'closed', 'closed', '', '82-revision-v1', '', '', '2016-02-01 02:28:39', '2016-02-01 02:28:39', '', 82, 'http://localhost/index.php/2016/02/01/82-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2016-02-01 02:34:54', '2016-02-01 02:34:54', '', 'Our Work', '', 'publish', 'closed', 'closed', '', 'our-work', '', '', '2016-02-01 02:34:54', '2016-02-01 02:34:54', '', 0, 'http://localhost/?page_id=84', 0, 'page', '', 0),
(85, 1, '2016-02-01 02:28:59', '2016-02-01 02:28:59', '', 'Our Work', '', 'inherit', 'closed', 'closed', '', '84-revision-v1', '', '', '2016-02-01 02:28:59', '2016-02-01 02:28:59', '', 84, 'http://localhost/index.php/2016/02/01/84-revision-v1/', 0, 'revision', '', 0),
(86, 1, '2016-02-01 02:29:07', '2016-02-01 02:29:07', '', 'What We Do', '', 'inherit', 'closed', 'closed', '', '82-revision-v1', '', '', '2016-02-01 02:29:07', '2016-02-01 02:29:07', '', 82, 'http://localhost/index.php/2016/02/01/82-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2016-02-01 02:34:30', '2016-02-01 02:34:30', 'Contact form here. [contact_bank form_id=1 show_title=true show_desc=false]', 'Contact/Get Quote', '', 'publish', 'closed', 'closed', '', 'contactget-quote', '', '', '2016-02-01 02:34:46', '2016-02-01 02:34:46', '', 0, 'http://localhost/?page_id=87', 0, 'page', '', 0),
(88, 1, '2016-02-01 02:29:14', '2016-02-01 02:29:14', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2016-02-01 02:29:14', '2016-02-01 02:29:14', '', 87, 'http://localhost/index.php/2016/02/01/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2016-02-01 02:35:03', '2016-02-01 02:35:03', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2016-02-01 02:35:03', '2016-02-01 02:35:03', '', 0, 'http://localhost/?page_id=89', 0, 'page', '', 0),
(90, 1, '2016-02-01 02:29:39', '2016-02-01 02:29:39', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2016-02-01 02:29:39', '2016-02-01 02:29:39', '', 89, 'http://localhost/index.php/2016/02/01/89-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2016-02-01 02:34:59', '2016-02-01 02:34:59', '', 'Recent', '', 'publish', 'closed', 'closed', '', 'recent', '', '', '2016-02-01 02:34:59', '2016-02-01 02:34:59', '', 0, 'http://localhost/?page_id=91', 0, 'page', '', 0),
(92, 1, '2016-02-01 02:29:47', '2016-02-01 02:29:47', '', 'Recent', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2016-02-01 02:29:47', '2016-02-01 02:29:47', '', 91, 'http://localhost/index.php/2016/02/01/91-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2016-02-01 02:30:01', '2016-02-01 02:30:01', '', 'Contact/Get Quote', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2016-02-01 02:30:01', '2016-02-01 02:30:01', '', 87, 'http://localhost/index.php/2016/02/01/87-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2016-02-01 02:34:46', '2016-02-01 02:34:46', 'Contact form here. [contact_bank form_id=1 show_title=true show_desc=false]', 'Contact/Get Quote', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2016-02-01 02:34:46', '2016-02-01 02:34:46', '', 87, 'http://localhost/index.php/2016/02/01/87-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2016-02-01 02:35:41', '2016-02-01 02:35:41', ' ', '', '', 'publish', 'closed', 'closed', '', '95', '', '', '2016-02-01 02:36:07', '2016-02-01 02:36:07', '', 0, 'http://localhost/?p=95', 2, 'nav_menu_item', '', 0),
(96, 1, '2016-02-01 02:35:41', '2016-02-01 02:35:41', ' ', '', '', 'publish', 'closed', 'closed', '', '96', '', '', '2016-02-01 02:36:07', '2016-02-01 02:36:07', '', 0, 'http://localhost/?p=96', 4, 'nav_menu_item', '', 0),
(97, 1, '2016-02-01 02:35:41', '2016-02-01 02:35:41', ' ', '', '', 'publish', 'closed', 'closed', '', '97', '', '', '2016-02-01 02:36:07', '2016-02-01 02:36:07', '', 0, 'http://localhost/?p=97', 5, 'nav_menu_item', '', 0),
(98, 1, '2016-02-01 02:35:41', '2016-02-01 02:35:41', ' ', '', '', 'publish', 'closed', 'closed', '', '98', '', '', '2016-02-01 02:36:07', '2016-02-01 02:36:07', '', 0, 'http://localhost/?p=98', 3, 'nav_menu_item', '', 0),
(99, 1, '2016-02-01 02:35:41', '2016-02-01 02:35:41', ' ', '', '', 'publish', 'closed', 'closed', '', '99', '', '', '2016-02-01 02:36:07', '2016-02-01 02:36:07', '', 0, 'http://localhost/?p=99', 6, 'nav_menu_item', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(79, 2, 0),
(95, 2, 0),
(96, 2, 0),
(97, 2, 0),
(98, 2, 0),
(99, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 6) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '0'),
(14, 1, 'session_tokens', 'a:1:{s:64:"efc3d3175bc09eb22201462c33d53904a7e022902933047ec58ed9a58d3f782d";a:4:{s:10:"expiration";i:1455503306;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:105:"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36";s:5:"login";i:1454293706;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '81'),
(16, 1, 'wporg_favorites', ''),
(17, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(18, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(19, 1, 'wp_user-settings', 'libraryContent=browse'),
(20, 1, 'wp_user-settings-time', '1452828468'),
(21, 1, 'nav_menu_recently_edited', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BLWpw1UCvPQpESX3cc.NxvzPUcmzOb1', 'admin', 'paulrdkirby@gmail.com', '', '2016-01-15 03:08:59', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

